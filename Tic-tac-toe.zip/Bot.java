public class Bot extends Player {

  boolean currentPlayer;

  public Bot (String name, char token, boolean currentPlayer) {
    super(name, token, currentPlayer);
  }

  public int getMove() {
    System.out.println("Hello");
    /*****************************
    insert code for bot here
    ******************************/
    return 0;
  }

}
class Spot {
  char tokenInPlace;
  int spotNum;
  boolean spotTaken;
}
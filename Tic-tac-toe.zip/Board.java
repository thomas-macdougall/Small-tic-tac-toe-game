class Board {
  
  Spot[][] board = new Spot[3][3];

  public Board() {
    int spotNumber = 0;
    for (int i = 0; i < 3; i++) {
      spotNumber++;
      for (int j = 0; j < 3; j++) {
        this.board[i][j] = new Spot();
        this.board[i][j].tokenInPlace = '-';
        this.board[i][j].spotNum = spotNumber;
        this.board[i][j].spotTaken = false;
        spotNumber++;
      }
      spotNumber--;
    }
  }

  public void viewBoard() {
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        System.out.print(this.board[i][j].tokenInPlace + " ");
      }
      System.out.println();
    }
  }

  public boolean checkIfMoveValid(int move) {
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        if (this.board[i][j].spotNum == move) {
          return this.board[i][j].spotTaken;
        }
      }
    }
    return false;
  }

  public void addTokenToSpot(int move, char token) {
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        if (this.board[i][j].spotNum == move) {
          this.board[i][j].tokenInPlace = token;
        }
      }
    }
  }

  // Loop through all cells of the board and if one is found to be empty (contains char '-') then return false.
  // Otherwise the board is full.
  public boolean isBoardFull() {
    boolean isFull = true;
      
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        if (this.board[i][j].tokenInPlace == '-') {
            isFull = false;
        }
      }
    }
    return isFull;
  }

  // Returns true if there is a win, false otherwise.
  // This calls our other win check functions to check the entire board.
  public boolean checkForWin() {
    return (checkRowsForWin() || checkColumnsForWin() || checkDiagonalsForWin());
  }

  // Loop through rows and see if any are winners.
  private boolean checkRowsForWin() {
    for (int i = 0; i < 3; i++) {
      if (checkRowCol(this.board[i][0].tokenInPlace, this.board[i][1].tokenInPlace, this.board[i][2].tokenInPlace) == true) {
        return true;
      }
    }
    return false;
  }

  // Loop through columns and see if any are winners.
  private boolean checkColumnsForWin() {
    for (int i = 0; i < 3; i++) {
      if (checkRowCol(this.board[0][i].tokenInPlace, this.board[1][i].tokenInPlace, this.board[2][i].tokenInPlace) == true) {
        return true;
      }
    }
    return false;
  }

  // Check the two diagonals to see if either is a win. Return true if either wins.
  private boolean checkDiagonalsForWin() {
    return ((checkRowCol(this.board[0][0].tokenInPlace, this.board[1][1].tokenInPlace, this.board[2][2].tokenInPlace) == true) || (checkRowCol(this.board[0][2].tokenInPlace, this.board[1][1].tokenInPlace, this.board[2][0].tokenInPlace) == true));
  }

  // Check to see if all three values are the same (and not empty) indicating a win.
  private boolean checkRowCol(char c1, char c2, char c3) {
    return ((c1 != '-') && (c1 == c2) && (c2 == c3));
  }
}
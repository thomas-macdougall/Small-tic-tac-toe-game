import java.util.Scanner;

public class HumanPlayer extends Player {

  boolean currentPlayer;

  public HumanPlayer (String name, char token, boolean currentPlayer) {
    super(name, token, currentPlayer);
  }

  public int getMove() {
    Scanner read = new Scanner(System.in);
    int move;
    System.out.println("Select box to insert token (1-9)? ");
    move = read.nextInt();
    return move;
  }

}
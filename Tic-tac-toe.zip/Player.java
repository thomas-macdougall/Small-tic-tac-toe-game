public abstract class Player {

  String name;
  char token;
  boolean currentPlayer;
  
  public Player(String name, char token, boolean currentPlayer) {
    this.name = name;
    this.token = token;
    this.currentPlayer = currentPlayer;
  }

  public void setCurrentPlayer(boolean currentPlayer) {
    this.currentPlayer = currentPlayer;
  }

  public boolean getCurrentPlayer() {
    return this.currentPlayer;
  }

  abstract int getMove();

}
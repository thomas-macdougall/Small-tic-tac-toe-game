import java.util.Scanner;

class Main {
  
  public static void main(String[] args) {
    Main game = new Main();
    Board board = new Board();

    String player1Name;
    String player2Name;
    Scanner read = new Scanner(System.in);
    System.out.println("Enter player1's name: ");
    player1Name = read.nextLine();
    System.out.println("Enter player2's name: ");
    player2Name = read.nextLine();
    
    HumanPlayer player1 = new HumanPlayer(player1Name, 'X', true);
    HumanPlayer player2 = new HumanPlayer(player2Name, 'O', false);

    player1.currentPlayer = true;
    player2.currentPlayer = false;

    game: while(true){
      board.viewBoard();
      if (board.checkForWin() && !player1.currentPlayer) {
        System.out.println("Winner is " + player1.name);
        break game;
      } else if (board.checkForWin() && !player2.currentPlayer) {
        System.out.println("Winner is " + player2.name);
        break game;
      } 
      
      if (board.isBoardFull()) {
        System.out.println("Draw");
        break game;
      }
      
      boolean playersMove = true;
      int move = 0;
      if (player1.currentPlayer == true) {
        while (playersMove) {
          move = player1.getMove();
          playersMove = board.checkIfMoveValid(move);
        }
        board.addTokenToSpot(move, player1.token);
        player1.currentPlayer = false;
        player2.currentPlayer = true;
      } else if (player2.currentPlayer == true) {
        while (playersMove) {
          move = player2.getMove();
          playersMove = board.checkIfMoveValid(move);
        }
        board.addTokenToSpot(move, player2.token);
        player1.currentPlayer = true;
        player2.currentPlayer = false;
      }
    }

  }
  
}